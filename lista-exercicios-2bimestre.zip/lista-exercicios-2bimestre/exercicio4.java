import java.util.Scanner;

public class exercicio4 {
    
    public static void main(String[] args){
        
        int num1;
        int num2;

        Scanner s = new Scanner(System.in);
        
        System.out.print("Numero A: ");
        num1 = s.nextInt();
        System.out.print("Numero B: ");
        num2 = s.nextInt();

        if(num1 > num2){
            System.out.println("Numero maior é: " + num1);
        } 
        else if (num2 > num1){
            System.out.println("Numero maior é: " + num2);
        }
        else{
            System.out.println("Os dois numeros são iguas: " + num1);
        }

    }
}
