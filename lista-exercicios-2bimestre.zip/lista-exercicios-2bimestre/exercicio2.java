import java.util.Scanner;

public class exercicio2 {
    
    public static void main(String[] args){
        
        String nome;
        int idade;
        String genero;
        String cor_favorita;
        String pratica_esporte;

        Scanner s = new Scanner(System.in); 

        System.out.print("Informe seu Nome: ");
        nome = s.nextLine();

        System.out.print("Informe sua Idade: ");
        idade = s.nextInt();

        System.out.print("Informe seu Genero: ");
        genero = s.nextLine();

        System.out.print("Informe sua Cor favorita: ");
        cor_favorita = s.nextLine();

        System.out.print("Pratica esporte?: ");
        pratica_esporte = s.nextLine();

        System.out.println("Nome informado: " + nome);
        System.out.println("Idade informada: " + idade);
        System.out.println("Genero informado: " + genero);
        System.out.println("Cor Favorita informada: " + cor_favorita);
        System.out.println("Pratica esporte: " + pratica_esporte );

    }
}