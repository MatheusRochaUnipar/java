import java.util.Scanner;

public class exercicio6 {
    
    public static void main(String[] args){
        
        int num1; 
        double elevado_2;
        double elevado_4;
        double elevado_6;
        double elevado_8;
        double elevado_10;

        Scanner s = new Scanner(System.in);
        
        System.out.print("Informe um numero: ");
        num1 = s.nextInt();

        elevado_2 = Math.pow(num1, 2);
        elevado_4 = Math.pow(num1, 4);
        elevado_6 = Math.pow(num1, 6);
        elevado_8 = Math.pow(num1, 8);
        elevado_10 = Math.pow(num1, 10);

        System.out.println("Numero informado: " + num1);
        System.out.println("Numero informado elevado a 2: " + elevado_2);
        System.out.println("Numero informado elevado a 4: " + elevado_4);
        System.out.println("Numero informado elevado a 6: " + elevado_6);
        System.out.println("Numero informado elevado a 8: " + elevado_8);
        System.out.println("Numero informado elevado a 10: " + elevado_10);

    }
}
