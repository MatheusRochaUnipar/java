import java.util.Scanner;

public class exercicio7 {
    
    public static void main(String[] args){
        
        int num1;
        int num2;

        Scanner s = new Scanner(System.in);
        
        System.out.print("Numero A: ");
        num1 = s.nextInt();
        System.out.print("Numero B: ");
        num2 = s.nextInt();

        System.out.println("Numeros informados:");
        System.out.println("Numero A: " + num1);
        System.out.println("Numero B: " + num2);
        System.out.println("Numero A maior que Numero B: " + (num1>num2));
        System.out.println("Numero A menor que Numero B: " + (num1<num2));
        System.out.println("Numero A igual Numero B: " + (num1==num2));
        System.out.println("Numero A diferente Numero B: " + (num1!=num2));


    }
}
