import java.util.Scanner;

public class exercicio9 {
    
    public static void main(String[] args){
        
        int num1;

        Scanner s = new Scanner(System.in);
        
        System.out.print("Informe um numero: ");
        num1 = s.nextInt();

        if (num1 % 2 == 0) {
            System.out.println("Seu numero é : Par");
        } else {
            System.out.println("Seu numero é: Impar");
        }
        
    }
}
