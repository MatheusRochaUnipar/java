import java.util.Scanner;

public class exercicio9 {

    public static void main(String[] args) {

        int num1;
        double elevado_2;
        double raiz_quadrada;

        Scanner s = new Scanner(System.in);

        System.out.print("Informe um numero: ");
        num1 = s.nextInt();

        elevado_2 = Math.pow(num1, 2);
        raiz_quadrada = Math.sqrt(num1);

        if (num1 >= 10 && num1 <= 100) {
            System.out.printf("Seu numero elevado a 2: %.5f%n", elevado_2);
        } 
        else if (num1 < 10 || num1 > 100) {
            System.out.printf("A raiz quadrada do seu numero é: %.5f%n", raiz_quadrada);
        } 
        else {
            System.out.println("Informe um numero valido!");
        }

    }
}
