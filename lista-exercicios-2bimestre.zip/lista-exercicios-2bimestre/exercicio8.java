import java.util.Scanner;

public class exercicio8 {
    
    public static void main(String[] args){
        
        int valor_inicial;
        int valor_final;
        int consumo_total;
        int media_diaria;

        Scanner s = new Scanner(System.in);
        
        System.out.print("Informe o valor do relógio da água(1º dia do mês): ");
        valor_inicial = s.nextInt();
        System.out.print("Informe o valor do relógio da água(30º dia do mês): ");
        valor_final = s.nextInt();

        consumo_total = valor_final - valor_inicial;
        media_diaria = consumo_total / 30;
        
        System.out.println("Consumo total em litros: " + consumo_total);
        System.out.println("Media diaria: " + media_diaria);

    }
}
