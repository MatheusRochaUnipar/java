import java.util.Scanner;

public class exercicio3 {
    
    public static void main(String[] args){
        
        int num1;
        int num2;

        int soma;
        int subtracao;
        int multiplicacao;
        double divisao;

        Scanner s = new Scanner(System.in);
        
        System.out.print("Numero A: ");
        num1 = s.nextInt();
        System.out.print("Numero B: ");
        num2 = s.nextInt();

        soma = num1 + num2;
        subtracao = num1 - num2;
        multiplicacao = num1 * num2;
        divisao = num1 / num2;

        System.out.println("Numeros informados:");
        System.out.println("Numero A: " + num1);
        System.out.println("Numero B: " + num2);
        System.out.println("Soma: " + soma);
        System.out.println("Subtração: " + subtracao);
        System.out.println("Multiplicação: " + multiplicacao);
        System.out.println("Divisão: " + divisao);

    }
}